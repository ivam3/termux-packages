#!/usr/bin/env python3
# -*- coding: utf-8 -*-
import sys
import os
import subprocess

# --- MECANISMO DE BOOTSTRAP PARA RICH ---
try:
    import rich
except ImportError:
    print("[!] La librería 'rich' no está instalada.")
    print("[*] Intentando instalación automática...")
    try:
        subprocess.check_call([sys.executable, "-m", "pip", "install", "rich"])
        print("[V] 'rich' instalado correctamente. Iniciando...")
    except Exception as e:
        print(f"[X] No se pudo instalar 'rich' automáticamente: {e}")
        print("[i] Por favor, ejecuta: pip install rich")
        sys.exit(1)
# ---------------------------------------

# Añadir el directorio actual al path para encontrar el paquete 'app'
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from app import Converter

if __name__ == "__main__":
    try:
        app = Converter()
        
        # Modo de verificación rápida (autofix ya ocurre en el __init__ del core)
        if len(sys.argv) > 1 and sys.argv[1] == "--check":
            print("\n[V] Entorno verificado y reparado.")
            sys.exit(0)
            
        app.main_menu()
    except KeyboardInterrupt:
        # Al presionar Ctrl+C, ejecutamos la salida original
        if 'app' in locals():
            app.exit_app()
        else:
            print("\n\nSaliendo...")
            sys.exit(0)
