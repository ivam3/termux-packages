#!/usr/bin/env bash
set -euo pipefail
source "$(dirname "$0")/lib.sh"

PWS=$(echo ${SHELL} | awk -F '/' '{print $NF}')
case $PWS in
    bash) BASHRC="${HOME}/.bashrc" ;;
    fish) BASHRC="${PREFIX}/etc/fish/config.fish" ;;
    zsh) BASHRC="${HOME}/.zshrc" ;;
esac
PLATFORM=$(detect_platform) || true

INFRA_VARS="export TMPDIR=\"\$PREFIX/tmp\"
export TMP=\"\$TMPDIR\"
export TEMP=\"\$TMPDIR\"
export OA_GLIBC=1"

PATH_LINE="export PATH=\"\$HOME/.local/bin:\$PATH\""
if [ -n "$PLATFORM" ]; then
    load_platform_config "$PLATFORM" "$(dirname "$(dirname "$0")")" 2>/dev/null || true
    if [ "${PLATFORM_NEEDS_NODEJS:-}" = true ]; then
        PATH_LINE="export PATH=\"\$HOME/.openclaw-android/bin:\$HOME/.openclaw-android/node/bin:\$HOME/.local/bin:\$PATH\""
    fi
fi

PLATFORM_VARS=""
PLATFORM_ENV_SCRIPT="${HOME}/.openclaw/platforms/$PLATFORM/env.sh"
if [ -n "$PLATFORM" ] && [ -f "$PLATFORM_ENV_SCRIPT" ]; then
    PLATFORM_VARS=$(bash "$PLATFORM_ENV_SCRIPT")
fi

ENV_BLOCK="${BASHRC_MARKER_START}
# platform: ${PLATFORM:-none}
${PATH_LINE}
${INFRA_VARS}"

if [ -n "$PLATFORM_VARS" ]; then
    ENV_BLOCK="${ENV_BLOCK}
${PLATFORM_VARS}"
fi

ENV_BLOCK="${ENV_BLOCK}
${BASHRC_MARKER_END}"

touch "$BASHRC"
if grep -qF "$BASHRC_MARKER_START" "$BASHRC"; then
    sed -i "/${BASHRC_MARKER_START//\//\\/}/,/${BASHRC_MARKER_END//\//\\/}/d" "$BASHRC"
fi
echo "" >> "$BASHRC"
echo "$ENV_BLOCK" >> "$BASHRC"

if [ ! -e "${PREFIX}/bin/ar" ] && [ -x "${PREFIX}/bin/llvm-ar" ]; then
    ln -s "${PREFIX}/bin/llvm-ar" "${PREFIX}/bin/ar"
fi
